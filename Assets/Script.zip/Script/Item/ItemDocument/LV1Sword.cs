using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LV1Sword : Item
{ 
    public override void UseItem()
    {
        Debug.Log("레벨1의 검 정상 작동");
    }
}
