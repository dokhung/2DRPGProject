using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemClick : MonoBehaviour
{
    public void OnItemClick()
    {
        Debug.Log("아이템을 클릭 함");
    }
}
