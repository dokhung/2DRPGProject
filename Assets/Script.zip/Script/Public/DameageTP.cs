using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
public class DameageTP : MonoBehaviour
{
    // private float Point = 0;
    // private float speed = 0.5f;
    // void Update()
    // {
    //     if (gameObject.activeSelf)
    //     {
    //         Point += Time.deltaTime;
    //         transform.Translate(0,1* speed * Time.deltaTime,0); 
    //     }
    // }

    // private void Start()
    // {
    //     // transform.DOMoveY(5, 2).SetEase(Ease.OutQuad); // 이동하는 동안 부드럽게 변화되도록 Ease 설정
    //     transform.DOMoveY(4, 1).SetRelative();
    // }
}
